using System.ComponentModel;
using System.Configuration;

namespace App.Properties
{
	internal sealed class Settings
	{
		private void SettingChangingEventHandler(object sender, SettingChangingEventArgs e)
		{
		}

		private void SettingsSavingEventHandler(object sender, CancelEventArgs e)
		{
		}
	}
}
